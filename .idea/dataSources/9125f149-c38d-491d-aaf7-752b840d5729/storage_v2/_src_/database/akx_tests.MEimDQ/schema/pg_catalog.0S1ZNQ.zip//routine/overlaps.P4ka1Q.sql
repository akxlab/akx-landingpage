create function "overlaps"(time without time zone, interval, time without time zone, time without time zone) returns boolean
    immutable
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function "overlaps"(time, interval, time, time) is 'intervals overlap?';

alter function "overlaps"(time, interval, time, time) owner to nicolascloutier;

